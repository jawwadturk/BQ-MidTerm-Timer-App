package com.example.bqmidtermproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
